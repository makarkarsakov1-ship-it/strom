import Foundation

public enum TransportStatusError: Error, LocalizedError {
    case incorrectLength
    case missingCriticalParameter
    case securityNotSatisfied
    case deniedByUser
    case invalidDataReceived
    case invalidParameterReceived
    case lockedDevice
    case txParsingFailed
    case internalError
    case unknownError(code: UInt16)

    public var errorDescription: String? {
        switch self {
        case .incorrectLength:
            return "Incorrect length"
        case .missingCriticalParameter:
            return "Missing critical parameter"
        case .securityNotSatisfied:
            return "Security not satisfied (dongle locked or have invalid access rights)"
        case .deniedByUser:
            return "Condition of use not satisfied (denied by the user?)"
        case .invalidDataReceived:
            return "Invalid data received"
        case .invalidParameterReceived:
            return "Invalid parameter received"
        case .lockedDevice:
            return "Locked device"
        case .txParsingFailed:
            return "Transaction parsing failed"
        case .internalError:
            return "Internal error, please report"
        case let .unknownError(code):
            return "Unknown error with status code: \(code)"
        }
    }

    public static func fromStatusCode(_ statusCode: UInt16) -> TransportStatusError {
        switch statusCode {
        case 0x6700:
            return .incorrectLength
        case 0x6800:
            return .missingCriticalParameter
        case 0x6982:
            return .securityNotSatisfied
        case 0x6985:
            return .deniedByUser
        case 0x6A80:
            return .invalidDataReceived
        case 0x6B00:
            return .invalidParameterReceived
        case 0x5515:
            return .lockedDevice
        case 0xB010:
            return .txParsingFailed
        case 0x6F00 ... 0x6FFF:
            return .internalError
        default:
            return .unknownError(code: statusCode)
        }
    }
}
