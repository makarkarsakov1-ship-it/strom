import Combine
import UIKit

public enum TKTheme: String, CaseIterable {
    case deepBlue
    case dark
    case light
    case system

    public var title: String {
        switch self {
        case .deepBlue:
            return "Deep Blue"
        case .dark:
            return "Dark"
        case .light:
            return "Light"
        case .system:
            return "System"
        }
    }

    public var userInterfaceStyle: UIUserInterfaceStyle {
        switch self {
        case .deepBlue:
            return .dark
        case .dark:
            return .dark
        case .light:
            return .light
        case .system:
            return .unspecified
        }
    }

    public var stringDescription: String {
        switch self {
        case .deepBlue:
            return "dark"
        case .dark:
            return "dark"
        case .light:
            return "light"
        case .system:
            return UIScreen.main.traitCollection.userInterfaceStyle == .dark ? "dark" : "light"
        }
    }

    var themeAppaearance: TKThemeAppearance {
        switch self {
        case .deepBlue:
            return DeepBlueThemeAppearance()
        case .dark:
            return DarkThemeAppearance()
        case .light:
            return LightThemeAppearance()
        case .system:
            return SystemThemeAppearance()
        }
    }
}

public final class TKThemeManager: ObservableObject {
    public typealias didUpdateThemeClosure = (TKTheme) -> Void

    public let objectWillChange = ObservableObjectPublisher()

    public var theme: TKTheme {
        willSet {
            assert(Thread.isMainThread, "TKThemeManager.theme must be set on the main thread")
            guard newValue != theme else { return }
            objectWillChange.send()
        }
        didSet {
            guard oldValue != theme else { return }
            didUpdateTheme()
        }
    }

    public static let shared = TKThemeManager()

    public private(set) var themeAppearance: TKThemeAppearance

    private let userDefaults = UserDefaults.standard

    init() {
        guard let themeIdentifier = userDefaults.string(forKey: .themeKey),
              let theme = TKTheme(rawValue: themeIdentifier)
        else {
            self.theme = .deepBlue
            self.themeAppearance = DeepBlueThemeAppearance()
            return
        }
        self.theme = theme
        self.themeAppearance = theme.themeAppaearance
    }

    private var observations = [UUID: didUpdateThemeClosure]()

    private var persistsTheme = true

    func applyPreviewTheme(_ newTheme: TKTheme) {
        guard newTheme != theme else { return }
        persistsTheme = false
        theme = newTheme
        persistsTheme = true
    }

    public func addEventObserver<T: AnyObject>(
        _ observer: T,
        closure: @escaping (T, TKTheme) -> Void
    ) {
        let id = UUID()
        let eventHandler: (TKTheme) -> Void = { [weak self, weak observer] theme in
            guard let self else { return }
            guard let observer else {
                observations.removeValue(forKey: id)
                return
            }

            closure(observer, theme)
        }
        observations[id] = eventHandler
    }

    private func didUpdateTheme() {
        themeAppearance = theme.themeAppaearance
        if persistsTheme {
            userDefaults.setValue(theme.rawValue, forKey: .themeKey)
        }
        observations.forEach { $0.value(theme) }
    }
}

private extension String {
    static let themeKey = "TKThemeIdentifier"
}
